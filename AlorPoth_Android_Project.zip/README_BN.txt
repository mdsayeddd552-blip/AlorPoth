আলোর পথ — Android Studio source project

এই ZIP-এ Android Studio-তে খোলার মতো Kotlin source project আছে। এখানে নামাজের সময় দেখানো, বাংলা/ইংরেজি তারিখ, হিজরি তারিখ, তাসবিহ কাউন্টার এবং অ্যালার্ম শিডিউল করার কোড যোগ করা হয়েছে।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
1) এই চ্যাটে সরাসরি compile/test করা installable APK দেওয়া হয়নি; এটি source project।
2) অফলাইনে সম্পূর্ণ আজান বাজাতে নিজের ব্যবহারের অনুমতি আছে এমন MP3 ফাইল app/src/main/res/raw/azan.mp3 নামে যোগ করতে হবে। raw ফোল্ডার তৈরি করা আছে, কিন্তু অডিও ফাইল কপিরাইট/অনুমতির কারণে অন্তর্ভুক্ত করা হয়নি।
3) অডিও ফাইল না থাকলে অ্যালার্ম সার্ভিস notification দেখাবে; সম্পূর্ণ আজান বাজবে না।
4) প্রথমবার নামাজের সময় আনতে ইন্টারনেট দরকার। সময় একবার এলে তা ফোনে সেভ হয়। সঠিকতা স্থানীয় মসজিদ/ইসলামিক কর্তৃপক্ষের সময়ের সঙ্গে মিলিয়ে নিন।
5) Android 12+ এ Settings-এ “Alarms & reminders” / exact alarm access অনুমতি চালু করতে হতে পারে. Android 13+ এ notification permission চাইতে পারে.
6) Battery optimization-ஐ manufacturer settings-ல் அனுமதிக்க வேண்டியிருக்கலாம்; Xiaomi/Redmi-তে Autostart/Background activity அனுமதியும் தேவை হতে পারে।

APK বানানো:
1. Android Studio ইনস্টল করে এই ফোল্ডার Open করুন।
2. Gradle Sync সম্পন্ন করুন।
3. Build > Build Bundle(s) / APK(s) > Build APK(s)।
4. APK: app/build/outputs/apk/debug/app-debug.apk

অডিও যোগ করা:
app/src/main/res/raw/azan.mp3 ফাইলে আপনার অনুমতিপ্রাপ্ত MP3 রাখুন (নাম অবশ্যই azan.mp3, ছোট হাতের অক্ষর)।
