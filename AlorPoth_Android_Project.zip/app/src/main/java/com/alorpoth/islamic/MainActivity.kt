package com.alorpoth.islamic

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var prayerBox: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var dateText: TextView
    private lateinit var tasbihText: TextView
    private var tasbih = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNeededPermissions()
        buildUi()
        showSavedTimes()
        loadPrayerTimes()
    }

    private fun requestNeededPermissions() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
            }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 24)
            setBackgroundColor(Color.rgb(244, 249, 243))
        }
        root.addView(TextView(this).apply {
            text = "☪  আলোর পথ"
            textSize = 31f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(18, 92, 65))
        }, matchWrap())

        root.addView(TextView(this).apply {
            text = "নামাজ • ক্যালেন্ডার • দৈনন্দিন ইবাদত"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(0, 7, 0, 18)
        }, matchWrap())

        dateText = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.rgb(35, 65, 49))
            setPadding(0, 4, 0, 12)
        }
        root.addView(dateText, matchWrap())
        updateDates()

        statusText = TextView(this).apply {
            text = "লোকেশন: টঙ্গী / ঢাকা, বাংলাদেশ"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, 0, 0, 10)
        }
        root.addView(statusText, matchWrap())

        root.addView(TextView(this).apply {
            text = "আজকের নামাজের সময়"
            textSize = 22f
            setTextColor(Color.rgb(18, 92, 65))
            setPadding(0, 8, 0, 12)
        }, matchWrap())

        prayerBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(prayerBox, matchWrap())

        root.addView(Button(this).apply {
            text = "নামাজের সময় আপডেট ও অ্যালার্ম সেট"
            setOnClickListener { loadPrayerTimes() }
        }, matchWrap())

        root.addView(TextView(this).apply {
            text = "তাসবিহ কাউন্টার"
            textSize = 21f
            setTextColor(Color.rgb(18, 92, 65))
            setPadding(0, 18, 0, 5)
        }, matchWrap())
        tasbihText = TextView(this).apply {
            text = "গণনা: 0"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            setPadding(0, 8, 0, 8)
        }
        root.addView(tasbihText, matchWrap())
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(Button(this).apply {
            text = " + ১ "
            setOnClickListener { tasbih++; tasbihText.text = "গণনা: $tasbih" }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(Button(this).apply {
            text = "রিসেট"
            setOnClickListener { tasbih = 0; tasbihText.text = "গণনা: 0" }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(buttons, matchWrap())

        root.addView(TextView(this).apply {
            text = "সেহরির শেষ সময়: ফজরের সময় • ইফতারের সময়: মাগরিবের সময়। প্রথমবার সময় আনতে ইন্টারনেট দরকার। অফলাইনে সম্পূর্ণ আজান বাজাতে অনুমতিপ্রাপ্ত azan.mp3 ফাইল অ্যাপের raw রিসোর্সে যোগ করুন।"
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, 16, 0, 0)
        }, matchWrap())

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun updateDates() {
        val now = Date()
        val english = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.ENGLISH).format(now)
        val bengali = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("bn", "BD")).format(now)
        val hijri = try {
            val islamic = android.icu.util.IslamicCalendar()
            islamic.time = now
            val day = islamic.get(Calendar.DAY_OF_MONTH)
            val month = islamic.get(Calendar.MONTH) + 1
            val year = islamic.get(Calendar.YEAR)
            "হিজরি: $day/$month/$year"
        } catch (_: Exception) { "হিজরি তারিখ ডিভাইসের ক্যালেন্ডার সেটিংস অনুযায়ী ভিন্ন হতে পারে" }
        dateText.text = "বাংলা লোকেল তারিখ: $bengali\nইংরেজি: $english\n$hijri"
    }

    private fun showSavedTimes() {
        val prefs = getSharedPreferences("prayer_times", MODE_PRIVATE)
        val names = listOf("ফজর" to "Fajr", "যোহর" to "Dhuhr", "আসর" to "Asr", "মাগরিব" to "Maghrib", "এশা" to "Isha")
        prayerBox.removeAllViews()
        var found = false
        names.forEach { (label, key) ->
            val time = prefs.getString(key, null)
            if (time != null) {
                found = true
                prayerBox.addView(prayerRow(label, time), matchWrap().apply { bottomMargin = 6 })
            }
        }
        if (!found) prayerBox.addView(TextView(this).apply {
            text = "ইন্টারনেট সংযোগ করে নামাজের সময় আপডেট করুন।"
            textSize = 16f
            setTextColor(Color.DKGRAY)
        }, matchWrap())
    }

    private fun prayerRow(label: String, time: String): View = TextView(this).apply {
        text = "$label      $time"
        textSize = 19f
        setTextColor(Color.rgb(34, 55, 43))
        setPadding(18, 14, 18, 14)
        setBackgroundColor(Color.WHITE)
    }

    private fun loadPrayerTimes() {
        statusText.text = "নামাজের সময় লোড হচ্ছে…"
        thread {
            try {
                val url = URL("https://api.aladhan.com/v1/timingsByCity?city=Tongi&country=Bangladesh&method=1")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"; connectTimeout = 12000; readTimeout = 12000
                }
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                val data = JSONObject(response).getJSONObject("data")
                val timings = data.getJSONObject("timings")
                val date = data.getJSONObject("date")
                val hijri = date.getJSONObject("hijri")
                val hijriText = "${hijri.getString("day")} ${hijri.getJSONObject("month").getString("en")} ${hijri.getString("year")} হিজরি"
                val prefs = getSharedPreferences("prayer_times", MODE_PRIVATE)
                val editor = prefs.edit()
                val prayerKeys = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
                prayerKeys.forEach { editor.putString(it, cleanTime(timings.getString(it))) }
                editor.putString("hijri", hijriText)
                editor.apply()
                val timeMap = prayerKeys.associateWith { cleanTime(timings.getString(it)) }
                PrayerScheduler.scheduleToday(this, timeMap)
                runOnUiThread {
                    statusText.text = "লোকেশন: টঙ্গী / ঢাকা • $hijriText"
                    showSavedTimes()
                    Toast.makeText(this, "সময় আপডেট ও অ্যালার্ম সেট করা হয়েছে", Toast.LENGTH_LONG).show()
                }
            } catch (_: Exception) {
                runOnUiThread {
                    statusText.text = "সময় লোড হয়নি। ইন্টারনেট পরীক্ষা করুন; আগে সেভ করা সময় থাকলে সেটি দেখা যাবে।"
                    showSavedTimes()
                    Toast.makeText(this, "নামাজের সময় আনতে সমস্যা হয়েছে", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun cleanTime(value: String): String = value.substringBefore(" ").trim()

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
