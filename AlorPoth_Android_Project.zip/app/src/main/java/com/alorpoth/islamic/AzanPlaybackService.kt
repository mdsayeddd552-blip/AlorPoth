package com.alorpoth.islamic

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.net.Uri
import android.provider.Settings
import android.widget.Toast

class AzanPlaybackService : Service() {
    private var player: MediaPlayer? = null
    private val channelId = "alorpoth_azan"

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAudio()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val prayerName = intent?.getStringExtra("prayer_name") ?: "নামাজ"
        startForeground(10, buildNotification(prayerName))
        playBundledAzan()
        return START_NOT_STICKY
    }

    private fun playBundledAzan() {
        stopAudio()
        val resourceId = resources.getIdentifier("azan", "raw", packageName)
        if (resourceId == 0) {
            // No bundled azan.mp3: keep the notification visible and use the device notification sound.
            try {
                val uri = Settings.System.DEFAULT_NOTIFICATION_URI
                player = MediaPlayer().apply {
                    setDataSource(this@AzanPlaybackService, uri)
                    setOnCompletionListener { stopAudio(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
                    setOnErrorListener { _, _, _ -> stopAudio(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); true }
                    prepare()
                    start()
                }
            } catch (_: Exception) { }
            return
        }
        try {
            player = MediaPlayer.create(this, resourceId)?.apply {
                setOnCompletionListener { stopAudio(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
                setOnErrorListener { _, _, _ -> stopAudio(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); true }
                start()
            }
        } catch (_: Exception) { }
    }

    private fun stopAudio() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "আজান অ্যালার্ম", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "আলোর পথ নামাজের সময়ের অ্যালার্ম"
                setSound(null, null)
                enableVibration(true)
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(prayerName: String): Notification {
        val stopIntent = Intent(this, AzanPlaybackService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(this, 88, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("আলোর পথ — $prayerName")
            .setContentText("নামাজের সময় হয়েছে। আজান বন্ধ করতে চাপ দিন।")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "আজান বন্ধ", stopPending)
            .build()
    }

    override fun onDestroy() { stopAudio(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_PLAY = "com.alorpoth.islamic.PLAY_AZAN"
        const val ACTION_STOP = "com.alorpoth.islamic.STOP_AZAN"
    }
}
