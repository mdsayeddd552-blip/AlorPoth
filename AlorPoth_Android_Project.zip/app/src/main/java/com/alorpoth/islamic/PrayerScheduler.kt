package com.alorpoth.islamic

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object PrayerScheduler {
    fun scheduleToday(context: Context, times: Map<String, String>) {
        val names = mapOf("Fajr" to "ফজর", "Dhuhr" to "যোহর", "Asr" to "আসর", "Maghrib" to "মাগরিব", "Isha" to "এশা")
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for ((key, value) in times) {
            try {
                val parts = value.split(":")
                if (parts.size < 2) continue
                val hour = parts[0].toInt()
                val minute = parts[1].toInt()
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
                }
                val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
                    putExtra("prayer_key", key)
                    putExtra("prayer_name", names[key] ?: key)
                }
                val pending = PendingIntent.getBroadcast(
                    context, key.hashCode(), intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                if (Build.VERSION.SDK_INT < 31 || alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
                } else {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
                }
            } catch (_: Exception) { }
        }
    }
}
