package com.alorpoth.islamic

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val prefs = context.getSharedPreferences("prayer_times", Context.MODE_PRIVATE)
            val map = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
                .mapNotNull { key -> prefs.getString(key, null)?.let { key to it } }
                .toMap()
            if (map.isNotEmpty()) PrayerScheduler.scheduleToday(context, map)
        }
    }
}
