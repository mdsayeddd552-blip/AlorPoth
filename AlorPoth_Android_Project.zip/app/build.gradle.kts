plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.alorpoth.islamic"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.alorpoth.islamic"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}
